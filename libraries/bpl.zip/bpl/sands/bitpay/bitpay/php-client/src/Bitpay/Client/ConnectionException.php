<?php 

namespace Bitpay\Client;

class ConnectionException extends \Exception
{

}
