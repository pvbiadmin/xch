<?php

namespace BPL\Mods\Terms;

function main(): string
{
	$str = '<div id="modal-1" class="uk-modal" style="z-index: 9999">
    <div class="uk-modal-dialog">
        <button type="button" class="uk-modal-close uk-close"></button>';
	$str .= '<h2 style="text-align: center">The Software <br>
<span style="font-size: larger">WEBSITE TERMS OF USE</span><br>
<span style="font-size: medium">(IMPORTANT - PLEASE READ)</span></h2>';
	$str .= '<p>Thank you for visiting the website (the “Website”) on which you found the link to these Terms Of Use 
		(the “Website”). The Website is an Internet property of The Software (referred to collectively as “The 
		Software,” “we” and “us”). You agree to be bound by these The Software Website Terms of Use (“Terms of Use”), 
		in their entirety, when you: (a) access the Website; (b) register for a newsletter or subscribe to a mailing 
		list or request information by and through the Website (“Subscription Services”); (c) register to participate 
		in promotions, contests and/or sweepstakes offered by The Software from time to time (each, a “Contest”); (d) 
		join, or attempt to join, an affiliate program or other membership organization featured on the Website 
		(“Membership Services”); and/or (e) order a product and/or service through the Website (“Vendor Services, and 
		together with the Subscription Services and Membership Services, the “Services”). The Software Privacy Policy 
		(“Privacy Policy”), the Official Contest Rules applicable to each Contest, The Software Purchase Agreement(s) 
		(“Purchase Agreement”), The Software Membership Agreement(s) (“Membership Agreement”), as well as any other 
		operating rules, policies, price schedules and other supplemental terms and conditions or documents that may be 
		published from time to time, are expressly incorporated herein by reference (collectively, the “Agreement”). 
		Please review the complete terms of the Agreement carefully. If you do not agree to the Agreement in its 
		entirety, you are not authorized to use the Services and/or Website in any manner or form.</p>';
	$str .= '<p>The Software SPECIFICALLY DENIES ACCESS TO THE WEBSITE AND/OR SERVICES BY ANY INDIVIDUAL THAT IS 
		COVERED BY THE CHILDREN’S ONLINE PRIVACY PROTECTION ACT OF 1998, AS AMENDED (“COPPA”). The Software RESERVES 
		THE RIGHT TO DENY ACCESS TO THE SERVICES AND/OR WEBSITE TO ANY INDIVIDUAL, IN ITS SOLE AND EXCLUSIVE 
		DISCRETION.</p>';
	$str .= '<h3>SCOPE AND MODIFICATION OF THE AGREEMENT</h3>';
	$str .= '<p>You agree to the terms and conditions outlined in the Agreement with respect to your use of the 
		Website. The Agreement constitutes the entire and only agreement between you and The Software with respect to 
		your use of the Website and supersedes all prior or contemporaneous agreements, representations, warranties 
		and/or understandings with respect to the Website. We may amend the Agreement from time to time in our sole 
		discretion, without specific notice to you. The latest Agreement will be posted on the Website, and you should 
		review the Agreement prior to using the Website. By your continued use of the Website and/or Services, you 
		hereby agree to comply with all the terms and conditions contained within the Agreement effective at that time. 
		Therefore, you should regularly check this page for updates and/or changes.</p>';
	$str .= '<h3>REQUIREMENTS</h3>';
	$str .= '<p>The Website and Services are available only to individuals who can enter into legally binding contracts 
		under applicable law. The Website and Services are not intended for use by individuals under the age of 
		eighteen (18). If you are under the age of eighteen (18), you do not have permission to use and/or access the 
		Website and/or Services.</p>';
	$str .= '<h3>DESCRIPTION OF THE SERVICES</h3>';
	$str .= '<h4>Subscription Services</h4>';
	$str .= '<p>Subject to the terms and conditions of the Agreement, by registering on the Website and receiving 
		approval from The Software, you can obtain, or attempt to obtain, for a fee or for no fee, the Subscription 
		Services. The Subscription Services will provide you with e-mail content, text and other materials 
		(“Subscription Content”) relevant to online marketing provided by The Software and its third party partners 
		(“Third Party Providers”). If you would like to discontinue receipt of the Subscription Content, simply email 
		us at support@fxrevenge.net. The Subscription Content contains comments, opinions and/or other materials that 
		are provided by The Software and Third Party Providers, and should not necessarily be relied upon. Please use 
		caution, common sense and safety when using the Subscription Content and/or Subscription Services. You agree 
		that The Software shall have no obligations and incur no liabilities to you in connection with any such 
		Subscription Content. The Software does not represent or warrant that the Subscription Content made available 
		in connection with the Subscription Services is accurate, complete or appropriate. You understand and agree 
		that The Software is not responsible or liable in any manner whatsoever for your inability to use the 
		Subscription Services and/or Subscription Content. You understand and agree that The Software shall not be 
		liable to you, any end-users or any third party, for any claim in connection with any of the Subscription 
		Services.</p>';
	$str .= '<h4>Membership Services</h4>';
	$str .= '<p>Subject to the terms and conditions of the Agreement and the Membership Agreement, by registering on 
		the Website, agreeing to the Membership Agreement and receiving approval from The Software, you can obtain, or 
		attempt to obtain, for a fee or for no fee, a Membership in one of the various Membership programs that MTS 
		Advertise OU offers. For a copy of the Membership Agreement, please visit the website for the specific 
		Membership. The Software Membership programs will enable you to access content, text and other materials 
		(“Member Content” and together with the Subscription Content, the “Content”) provided by The Software and 
		certain Third Party Providers, designed to assist Members in their online marketing ventures. The Member 
		Content contains comments, opinions and other materials that are provided by The Software Third Party 
		Providers, and should not necessarily be relied upon. Please use caution, common sense and safety when using 
		the Member Content and/or Membership Services. You agree that The Software shall have no obligations and incur 
		no liabilities to you in connection with any such Member Content. The Software does not represent or warrant 
		that the Member Content made available in connection with the Membership Services is accurate, complete or 
		appropriate. You understand and agree that The Software is not responsible or liable in any manner whatsoever 
		for your inability to use the Membership Services and/or Member Content. You understand and agree that The 
		Software shall not be liable to you, any end-users or any third party, for any claim in connection with any of 
		the Membership Services.</p>';
	$str .= '<h4>Vendor Services</h4>';
	$str .= '<p>By completing the applicable purchase order forms, you can obtain, or attempt to obtain, certain 
		products and/or services from the Website. The products and/or services featured on the Website may contain 
		descriptions that are provided directly by the Third Party Provider manufacturers or distributors of such 
		items. The Software does not represent or warrant that the descriptions of such items are accurate or complete. 
		You understand and agree that The Software is not responsible or liable in any manner whatsoever for your 
		inability to obtain products and/or services from the Website or for any dispute with the product’s seller, 
		distributor and end-user consumers. You understand and agree that The Software shall not be liable to you or 
		any third party for any claim in connection with any of the products and/or services offered on the 
		Website.</p>';
	$str .= '<h4>General</h4>';
	$str .= '<p>The information that you must supply in connection with registering for the Services may include, 
		without limitation, some or all of the following: (a) your full name; (b) company name; (c) e-mail address; 
		(d) mailing address (and billing address if different); (e) home telephone number; (f) work telephone number; 
		(g) telecopier number; (h) credit card information; and/or (i) any other information requested on the 
		applicable registration form (“Service Registration Data”). You agree to provide true, accurate, current and 
		complete Service Registration Data. The Software has the right to reject any Service Registration Data where it 
		is determined, in the sole and exclusive discretion of The Software, that: (i) you are in breach of any portion 
		of the Agreement; and/or (ii) the Service Registration Data that you provided is incomplete, fraudulent, a 
		duplicate or otherwise unacceptable. The Software may change the Registration Data criteria at any time, in its 
		sole discretion.</p>';
	$str .= '<p>Unless explicitly stated otherwise, any future offer(s) made available to you on the Website that 
		augment(s) or otherwise enhance(s) the current features of the Website shall be subject to the Agreement. You 
		understand and agree that The Software is not responsible or liable in any manner whatsoever for your inability 
		to use and/or qualify for the Services. You understand and agree that The Software shall not be liable to you 
		or any third party for any modification, suspension or discontinuation of any Services or other product, 
		service or promotion offered by The Software and/or any of its Third Party Providers. If MTS Advertise OU 
		terminates the Agreement and/or any Services for any reason, MTS Advertise OU shall have no liability or 
		responsibility to you. You understand and agree that refusal to use the Website is your sole right and remedy 
		with respect to any dispute that you may have with The Software.</p>';
	$str .= '<h3>CONTESTS</h3>';
	$str .= '<p>From time-to-time, The Software offers promotional prizes and other awards via Contests. By providing 
		true and accurate information in connection with the applicable Contest registration form, and agreeing to the 
		Official Contest Rules applicable to each Contest, you can enter for a chance to win the promotional prizes 
		offered through each Contest. To enter into the Contests featured on the Website, you must first fully complete 
		the applicable entry form. You agree to provide true, accurate, current and complete Contest Registration Data. 
		The Software has the right to reject any Contest Registration Data where it is determined, in the sole and 
		exclusive discretion of The Software, that: (i) you are in breach of any portion of the Agreement; and/or (ii) 
		the Contest Registration Data that you provided is incomplete, fraudulent, a duplicate or otherwise 
		unacceptable. The Software may change the Registration Data criteria at any time, in its sole discretion.</p>';
	$str .= '<h3>LICENSE GRANT</h3>';
	$str .= '<p>As a user of the Website, you are granted a non-exclusive, non-transferable, revocable and limited 
		license to access and use the Website, Content and associated material in accordance with the Agreement. The 
		Software may terminate this license at any time for any reason. You may use the Website and Content on one 
		computer for your own personal, non-commercial use. No part of the Website, Content, Contests and/or Services 
		may be reproduced in any form or incorporated into any information retrieval system, electronic or mechanical. 
		You may not use, copy, emulate, clone, rent, lease, sell, modify, decompile, disassemble, reverse engineer or 
		transfer the Website, Content, Contests and/or Services or any portion thereof. The Software reserves any 
		rights not explicitly granted in the Agreement. You may not use any device, software or routine to interfere or 
		attempt to interfere with the proper working of the Website. You may not take any action that imposes an 
		unreasonable or disproportionately large load on The Software’s infrastructure. Your right to use the Website, 
		Content, Contests and/or Services is not transferable.</p>';
	$str .= '<h3>PROPRIETARY RIGHTS</h3>';
	$str .= '<p>The content, organization, graphics, design, compilation, magnetic translation, digital conversion, 
		software, services and other matters related to the Website, Content, Contests and Services are protected under 
		applicable copyrights, trademarks and other proprietary (including, but not limited to, intellectual property) 
		rights. The copying, redistribution, publication or sale by you of any part of the Website, Content, Contests 
		and/or Services is strictly prohibited. Systematic retrieval of material from the Website, Content, Contests 
		and/or Services by automated means or any other form of scraping or data extraction in order to create or 
		compile, directly or indirectly, a collection, compilation, database or directory without written permission 
		from The Software is prohibited. You do not acquire ownership rights to any content, document, software, 
		services or other materials viewed at or through the Website, Content, Contests and/or Services. The posting of 
		information or material on the Website, or by and through the Services, by The Software does not constitute a 
		waiver of any right in or to such information and/or materials. The Software name and logo, and all 
		associated graphics, icons and service names, are trademarks of The Software. All other trademarks appearing on 
		the Website or by and through the Services are the property of their respective owners. The use of any 
		trademark without the applicable owner’s express written consent is strictly prohibited.</p>';
	$str .= '<h3>HYPERLINKING TO THE WEBSITE, CO-BRANDING, "FRAMING" AND/OR REFERENCING THE WEBSITE PROHIBITED</h3>';
	$str .= '<p>Unless expressly authorized by The Software, no one may hyperlink the Website, or portions thereof 
		(including, but not limited to, logotypes, trademarks, branding or copyrighted material), to their website or 
		web venue for any reason. Further, ”framing” the Website and/or referencing the Uniform Resource Locator 
		(”URL”) of the Website in any commercial or non-commercial media without the prior, express, written permission 
		of The Software is strictly prohibited. You specifically agree to cooperate with the Website to remove or 
		cease, as applicable, any such content or activity. You hereby acknowledge that you shall be liable for any and 
		all damages associated therewith.</p>';
	$str .= '<h3>EDITING, DELETING AND MODIFICATION</h3>';
	$str .= '<p>We reserve the right in our sole discretion to edit and/or delete any documents, information or other 
		content appearing on the Website.</p>';
	$str .= '<h3>DISCLAIMER</h3>';
	$str .= '<p>THE WEBSITE, SERVICES, CONTESTS, CONTENT, ANY THIRD PARTY PRODUCTS THAT YOU MAY RECEIVE FROM ONE OF OUR 
		THIRD PARTY PROVIDERS, AND/OR ANY OTHER PRODUCTS AND/OR SERVICES THAT YOU MAY APPLY FOR THROUGH THE WEBSITE ARE 
		PROVIDED TO YOU ON AN “AS IS” AND “AS AVAILABLE” BASIS AND ALL WARRANTIES, EXPRESS AND IMPLIED, ARE DISCLAIMED 
		TO THE FULLEST EXTENT PERMISSIBLE PURSUANT TO APPLICABLE LAW (INCLUDING, BUT NOT LIMITED TO, THE DISCLAIMER OF 
		ANY WARRANTIES OF MERCHANTABILITY, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY AND/OR FITNESS FOR A PARTICULAR 
		PURPOSE). IN PARTICULAR, BUT NOT AS A LIMITATION THEREOF, The Software MAKES NO WARRANTY THAT: (A) THE WEBSITE, 
		SERVICES, CONTESTS, CONTENT, ANY THIRD PARTY PRODUCTS THAT YOU MAY RECEIVE FROM ONE OF OUR THIRD PARTY 
		PROVIDERS, AND/OR ANY OTHER PRODUCTS AND/OR SERVICES THAT YOU MAY APPLY FOR THROUGH THE WEBSITE WILL MEET YOUR 
		REQUIREMENTS; (B) THE WEBSITE, SERVICES, CONTESTS, CONTENT, ANY THIRD PARTY PRODUCTS THAT YOU MAY RECEIVE FROM 
		ONE OF OUR THIRD PARTY PROVIDERS, AND/OR ANY OTHER PRODUCTS AND/OR SERVICES THAT YOU MAY APPLY FOR THROUGH THE 
		WEBSITE WILL BE UNINTERRUPTED, TIMELY, SECURE OR ERROR-FREE; (C) YOU WILL QUALIFY FOR THE CONTESTS AND/OR 
		SERVICES; OR (D) THE RESULTS THAT MAY BE OBTAINED FROM THE USE OF THE WEBSITE, SERVICES, CONTESTS, CONTENT, ANY 
		THIRD PARTY PRODUCTS THAT YOU MAY RECEIVE FROM ONE OF OUR THIRD PARTY PROVIDERS, AND/OR ANY OTHER PRODUCTS 
		AND/OR SERVICES THAT YOU MAY APPLY FOR THROUGH THE WEBSITE WILL BE ACCURATE OR RELIABLE. THE WEBSITE, SERVICES, 
		CONTESTS, CONTENT, ANY THIRD PARTY PRODUCTS THAT YOU MAY RECEIVE FROM ONE OF OUR THIRD PARTY PROVIDERS, AND/OR 
		ANY OTHER PRODUCTS AND/OR SERVICES THAT YOU MAY APPLY FOR THROUGH THE WEBSITE MAY CONTAIN BUGS, ERRORS, 
		PROBLEMS OR OTHER LIMITATIONS. WE WILL NOT BE LIABLE FOR THE AVAILABILITY OF THE UNDERLYING INTERNET CONNECTION 
		ASSOCIATED WITH THE WEBSITE. NO ADVICE OR INFORMATION, WHETHER ORAL OR WRITTEN, OBTAINED BY YOU FROM The 
		Software, ANY OF ITS THIRD PARTY PROVIDERS OR OTHERWISE THROUGH OR FROM THE WEBSITE, SHALL CREATE ANY WARRANTY 
		NOT EXPRESSLY STATED IN THE AGREEMENT.</p>';
	$str .= '<h3>DISCLAIMER FOR HARM CAUSED BY DOWNLOADS</h3>';
	$str .= '<p>Visitors download information from the Website at their own risk. The Software makes no warranty that 
		such downloads are free of corrupting computer codes including, but not limited to, viruses and worms.</p>';
	$str .= '<h3>LIMITATION OF LIABILITY</h3>';
	$str .= '<p>YOU EXPRESSLY UNDERSTAND AND AGREE THAT The Software SHALL NOT BE LIABLE TO YOU OR ANY THIRD PARTY FOR 
		ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL AND/OR EXEMPLARY DAMAGES INCLUDING, BUT NOT LIMITED 
		TO, DAMAGES FOR LOSS OF PROFITS, GOODWILL, USE, DATA OR OTHER INTANGIBLE LOSSES (EVEN IF The Software HAS BEEN 
		ADVISED OF THE POSSIBILITY OF SUCH DAMAGES), TO THE FULLEST EXTENT PERMISSIBLE BY LAW FOR: (A) THE USE OR THE 
		INABILITY TO USE THE WEBSITE, SERVICES, CONTESTS, CONTENT, ANY THIRD PARTY PRODUCTS THAT YOU MAY RECEIVE FROM 
		ONE OF OUR THIRD PARTY PROVIDERS, AND/OR ANY OTHER PRODUCTS AND/OR SERVICES THAT YOU MAY APPLY FOR THROUGH THE 
		WEBSITE; (B) THE COST OF PROCUREMENT OF SUBSTITUTE GOODS AND SERVICES RESULTING FROM ANY GOODS, DATA, 
		INFORMATION AND/OR SERVICES PURCHASED OR OBTAINED FROM, OR TRANSACTIONS ENTERED INTO THROUGH, THE WEBSITE; (C) 
		THE FAILURE TO QUALIFY FOR THE CONTESTS, SERVICES OR THIRD PARTY PRODUCTS FROM ANY OF OUR THIRD PARTY 
		PROVIDERS, OR ANY SUBSEQUENT DENIAL OF THIRD PARTY PRODUCTS FROM SAME; (D) THE UNAUTHORIZED ACCESS TO, OR 
		ALTERATION OF, YOUR REGISTRATION DATA; AND (E) ANY OTHER MATTER RELATING TO THE INABILITY TO USE THE WEBSITE, 
		SERVICES, CONTESTS, CONTENT, ANY THIRD PARTY PRODUCTS THAT YOU MAY RECEIVE FROM ONE OF OUR THIRD PARTY 
		PROVIDERS, AND/OR ANY OTHER PRODUCTS AND/OR SERVICES THAT YOU MAY APPLY FOR THROUGH THE WEBSITE. THIS 
		LIMITATION APPLIES TO ALL CAUSES OF ACTION, IN THE AGGREGATE INCLUDING, BUT NOT LIMITED TO, BREACH OF CONTRACT, 
		BREACH OF WARRANTY, NEGLIGENCE, STRICT LIABILITY, MISREPRESENTATIONS AND ANY AND ALL OTHER TORTS. YOU HEREBY 
		RELEASE The Software AND ALL OF The Software’S THIRD PARTY PROVIDERS FROM ANY AND ALL OBLIGATIONS, LIABILITIES 
		AND CLAIMS IN EXCESS OF THE LIMITATION STATED HEREIN. IF APPLICABLE LAW DOES NOT PERMIT SUCH LIMITATION, THE 
		MAXIMUM LIABILITY OF The Software TO YOU UNDER ANY AND ALL CIRCUMSTANCES WILL BE FIVE HUNDRED DOLLARS 
		($500.00). THE NEGATION OF DAMAGES SET FORTH ABOVE IS A FUNDAMENTAL ELEMENT OF THE BASIS OF THE BARGAIN BETWEEN 
		YOU AND The Software. THE INABILITY TO USE THE WEBSITE, SERVICES, CONTESTS, CONTENT, ANY THIRD PARTY PRODUCTS 
		THAT YOU MAY RECEIVE FROM ONE OF OUR THIRD PARTY PROVIDERS, AND/OR ANY OTHER PRODUCTS AND/OR SERVICES THAT YOU 
		MAY APPLY FOR THROUGH THE WEBSITE WOULD NOT BE PROVIDED TO YOU WITHOUT SUCH LIMITATIONS.</p>';
	$str .= '<h3>INDEMNIFICATION</h3>';
	$str .= '<p>You agree to indemnify and hold The Software, each of their parents, subsidiaries and affiliates, and 
		each of their respective members, officers, directors, employees, agents, co-branders and/or other partners, 
		harmless from and against any and all claims, expenses (including reasonable attorneys’ fees), damages, suits, 
		costs, demands and/or judgments whatsoever, made by any third party due to or arising out of: (a) your use of 
		the Website, Services, Content and/or entry into any Contest; (b) your breach of the Agreement; and/or (c) your 
		violation of any rights of another individual and/or entity. The provisions of this paragraph are for the 
		benefit of The Software, each of their parents, subsidiaries and/or affiliates, and each of their respective 
		officers, directors, members, employees, agents, shareholders, licensors, suppliers and/or attorneys. Each of 
		these individuals and entities shall have the right to assert and enforce these provisions directly against you 
		on its own behalf.</p>';
	$str .= '<h3>THIRD PARTY WEBSITES</h3>';
	$str .= '<p>The Website may provide links to and/or refer you to other Internet websites and/or resources 
		including, but not limited to, those owned and operated by Third Party Providers. Because The Software has no 
		control over such third party websites and/or resources, you hereby acknowledge and agree that The Software is 
		not responsible for the availability of such third party websites and/or resources. Furthermore, The Software 
		does not endorse, and is not responsible or liable for, any terms and conditions, privacy policies, content, 
		advertising, services, products and/or other materials at or available from such third party websites or 
		resources, or for any damages and/or losses arising therefrom.</p>';
	$str .= '<h3>PRIVACY POLICY/VISITOR INFORMATION</h3>';
	$str .= '<p>Use of the Website, and all comments, feedback, information, Registration Data and/or materials that 
		you submit through or in association with the Website, is subject to our Privacy Policy. We reserve the right 
		to use all information regarding your use of the Website, and any and all other personally identifiable 
		information provided by you, in accordance with the terms of our Privacy Policy.</p>';
	$str .= '<h3>LEGAL WARNING</h3>';
	$str .= '<p>Any attempt by any individual, whether The Software customer or not, to damage, destroy, tamper with, 
		vandalize and/or otherwise interfere with the operation of the Website, is a violation of criminal and civil 
		law and The Software will diligently pursue any and all remedies in this regard against any offending 
		individual or entity to the fullest extent permissible by law and in equity.</p>';
	$str .= '<h3>CHOICE OF LAW/VENUE</h3>';
	$str .= '<p>Any disputes arising out of or related to the Agreement shall be governed by and construed in 
		accordance with the laws of Estonia (without regard to conflict of law principles). Any award rendered shall be 
		final and conclusive to the parties and a judgment thereon may be entered in any court of competent 
		jurisdiction. Nothing herein shall be construed to preclude any party from seeking injunctive relief in order 
		to protect its rights pending an outcome in arbitration. To the extent permitted by law, you agree that you 
		will not bring, join or participate in any class action lawsuit as to any claim, dispute or controversy that 
		you may have against The Software. and each of their legal representatives, affiliates, subsidiaries, parents, 
		agencies and their respective members, officers, directors, employees and agents. You agree to the entry of 
		injunctive relief to stop such a lawsuit or to remove you as a participant in the suit. You agree to pay the 
		attorney’s fees and court costs that The Softwareurs in seeking such relief. The Agreement does not constitute 
		a waiver of any of your rights and remedies to pursue a claim individually and not as a class action in binding 
		arbitration as provided above. This provision preventing you from bringing, joining or participating in class 
		action lawsuits is an independent agreement. Should any part of the Agreement be held invalid or unenforceable, 
		that portion shall be construed consistent with applicable law and the remaining portions shall remain in full 
		force and effect.</p>';
	$str .= '</div>
</div>';

	return $str;
}