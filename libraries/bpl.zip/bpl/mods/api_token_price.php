<?php

namespace BPL\Mods\API_Token_Price;

require_once 'bpl/mods/file_get_contents_curl.php';
require_once 'bpl/mods/helpers.php';

use Exception;

use function BPL\Mods\File_Get_Contents_Curl\main as file_get_contents_curl;

/**
 * @param   string  $token
 *
 * @return array|mixed
 *
 * @since version
 */
function main(string $token)
{
	$data = [];

	if (in_array(trim($token), list_token(), true))
	{
		$url = 'https://api.binance.com/api/v3/ticker/price?symbol=' . (
			$token === 'USDT' ? 'TUSDUSDT' : $token . 'USDT');

		try
		{
			$json = !in_array('curl', get_loaded_extensions()) || is_localhost() ?
				@file_get_contents($url) : file_get_contents_curl($url);

			$data = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
		}
		catch (Exception $e)
		{
			echo $e->getMessage();
		}
	}

	return $data;
}

/**
 *
 * @return string[]
 *
 * @since version
 */
function list_token(): array
{
	return [
		'USDT',
//		'BTC',
		'ETH',
		'BNB',
		'LTC',
		'ADA',
		'USDC',
		'LINK',
		'DOGE',
		'DAI',
		'BUSD',
		'SHIB',
		'UNI',
		'MATIC',
		'DOT',
		'TRX',
		'BCH'
	];
}

/**
 * @param   string[]  $whitelist
 *
 * @return bool
 *
 * @since version
 */
function is_localhost(array $whitelist = ['127.0.0.1', '::1']): bool
{
	return in_array($_SERVER['REMOTE_ADDR'], $whitelist, true);
}