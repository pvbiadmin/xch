<?php

namespace BPL\Jumi\Unblock;

require_once 'bpl/mods/block_unblock.php';

use function BPL\Mods\Block_Unblock\main as unblock;

unblock('unblock');