<?php

namespace BPL\Jumi\Member_Info;

require_once 'bpl/mods/root_url_upline.php';
require_once 'bpl/mods/helpers.php';

use function BPL\Mods\Root_Url_Upline\main as root_url;

use function BPL\Mods\Url_SEF\sef;
use function BPL\Mods\Url_SEF\qs;

use function BPL\Mods\Helpers\session_get;
use function BPL\Mods\Helpers\page_validate;
use function BPL\Mods\Helpers\menu;
use function BPL\Mods\Helpers\input_get;
use function BPL\Mods\Helpers\db;
use function BPL\Mods\Helpers\settings;
use function BPL\Mods\Helpers\user;

main();

/**
 *
 *
 * @since version
 */
function main()
{
	$user_id  = session_get('user_id');
	$usertype = session_get('usertype');

	$uid = input_get('uid');

	page_validate();

	$str = menu();

	if ($uid !== '')
	{
		$user_id = $uid;
	}

	$str .= view_table($user_id, $usertype);
	$str .= scripts();

	echo $str;
}

/**
 * @param $user_id
 *
 * @return array|mixed
 *
 * @since version
 */
function directs($user_id)
{
	$db = db();

	return $db->setQuery(
		'SELECT * ' .
		'FROM network_users ' .
		'WHERE sponsor_id = ' . $db->quote($user_id)
	)->loadObjectList();
}

/**
 * @param $user_id
 * @param $usertype
 *
 * @return string
 *
 * @since version
 */
function view_table($user_id, $usertype): string
{
	$settings_plans = settings('plans');

	$user = user($user_id);

	$str = '<h1 style="alignment: center">' . $user->username . '</h1>
<table class="category table table-striped table-bordered table-hover">';

	if ($settings_plans->direct_referral)
	{
		$str .= '<tr>
        <td>' . $settings_plans->direct_referral_name . ' Link:</td>
        <td>';

		$http = 'http';

		$link = $http . '://' . $_SERVER['SERVER_NAME'] . root_url() . '/' . $user->username;

		$str .= '<input type="text" class="width-dynamic proba dva" value="' . $link .
			'" style="align-self: center; min-width: 88px; max-width: 888px" id="myLink" readonly>';

		$str .= '</td>
	        <td>
	            <button onClick="copyLink()" class="uk-button uk-button-primary" style="float:left">Copy</button>
	        </td>
	    </tr>';
	}

	$str .= '<tr>
	    <td>Full Name:</td>
	    <td colspan="2">' . (!empty($user->fullname) ? $user->fullname : '-') . '</td>
	</tr>';

	$str .= '<tr>
	    <td>Account Type:</td>
	    <td colspan="2">' . settings('entry')->{$user->account_type . '_package_name'} . '</td>
	</tr>';

	$str .= ($settings_plans->royalty ? '<tr>
        <td>' . $settings_plans->royalty_name . ':</td>
        <td>' . settings('royalty')->{$user->rank . '_rank_name'} . '</td>
    </tr>' : '');

	$str .= '<tr>
	    <td>Joined:</td>
	    <td colspan="2">' . date('M j, Y - g:i A', $user->date_registered) . '</td>
	</tr>';

	if ($settings_plans->direct_referral)
	{
		$str .= '<tr>
	        <td>Sponsored Members:</td>
	        <td colspan="2">' . count(directs($user_id)) . '</td>
	    </tr>
	    <tr>
	        <td>Sponsor:</td>
	        <td colspan="2">';

		$tmp = user($user->sponsor_id);

		$str .= (!empty($tmp) && $tmp->username !== '') ? '<a href="' . sef(44) .
			qs() . 'uid=' . $user->sponsor_id . '">' . $tmp->username . '</a>' : '-';

		$str .= '</td>
    	</tr>';
	}

	$str .= '<tr>
	    <td>Balance:</td>
	    <td colspan="2">' .
		number_format($user->payout_transfer, 2) .
		' ' . settings('ancillaries')->currency . '</td>
	</tr>
	<tr>
	    <td>Address:</td>
	    <td colspan="2">';

	$tmp = explode('|', $user->address);

	$country = (isset($tmp[4]) && $tmp[4] !== '') ? (get_country_name($tmp[4])) : '';

	$str .= (!empty($user->address) ? ($tmp[0] . ' ' . $tmp[1] .
		'<br>' . $tmp[2] . ', ' . $tmp[3] . '<br>' . $country) : '-');

	$str .= '</td>
	</tr>
	<tr>
	    <td>Email:</td>
	    <td colspan="2">' . (!empty($user->email) ? $user->email : '-') . '</td>
	</tr>
	<tr>
	    <td>Contact Info:</td>
	    <td colspan="2">' . contact_info($user->contact) . '</td>
	</tr>
	<tr>
	    <td>Payment Method:</td>';
//	$str .= '<td colspan="2">' . (!empty($user->bank) ? nl2br($user->bank) : '-') . '</td>';
	$str .= '<td colspan="2">' . payment_info($user->payment_method) . '</td>';
	$str .= '</tr>
	</table>
	<div class="uk-grid center">
	<div class="uk-width-1-1" data-uk-margin>';

//	$str .= $user->account_type === 'starter' ? '' : '<div class="uk-button-group" style="padding-right: 2px">
//		    <a href="' . sef(65) . qs() . 's=' . $user->username . '"
//		       class="uk-button" target="_parent">Add Entry</a>
//		</div>';

//	$str .= $user->account_type === 'starter' ? '' : '<div class="uk-button-group" style="padding-right: 5px">
////	    <a href="' . ($settings_plans->binary_pair ? sef(21) :
////			sef(24)) . qs() . 'uid=' . $user->id . '" class="uk-button"
////	       target="_parent">View Genealogy' . '</a></div>';

	$str .= (($user_id !== '') ? '<div class="uk-button-group" style="padding-right: 5px"><a href="' .
		sef(60) . qs() . 'uid=' . $user->id . '"
       class="uk-button" target="_parent">Update Profile</a></div>' : '');

	$str .= (($usertype === 'Admin') ? '<div class="uk-button-group" style="padding-right: 5px"><a href="' .
		sef(106) . qs() . 'uid=' . $user->id . '"
       class="uk-button" target="_parent">View Transactions</a></div>' : '');

	$str .= '</div></div>';

	return $str;
}

function payment_info($payment_method): string
{
	$pmu = json_decode($payment_method, true);

	$str = '';

	if (!empty($pmu))
	{
		foreach ($pmu as $k => $v)
		{
			$str .= '<p class="category table table-bordered">';
			$str .= '<a class="uk-button uk-button-success uk-button-small" href="javascript:void(0)">';
			$str .= strtoupper($k);
			$str .= '</a>';

			if (!is_array($v))
			{
				$str .= '<small style="padding-left: 7px"><b>' . $v . '</b></small>';
			}
			else
			{
				foreach ($v as $x => $y)
				{
					$str .= '<small style="padding-left: 7px"><b>' . strtoupper($x) . ': ' . $y . '</b></small>';
				}
			}

			$str .= '</p>';
		}
	}

	return $str;
}

function contact_info($contact): string
{
	$ciu = json_decode($contact, true);

	$str = '';

	if (!empty($ciu))
	{
		foreach ($ciu as $k => $v)
		{
			$str .= '<p class="category table table-bordered">';
			$str .= '<a class="uk-button uk-button-small" href="javascript:void(0)">';
			$str .= strtoupper($k);
			$str .= '</a>';

			if (!is_array($v))
			{
				$str .= '<small style="padding-left: 7px"><b>' . $v . '</b></small>';
			}

			$str .= '</p>';
		}
	}

	return $str;
}

/**
 * @param $country_id
 *
 * @return mixed
 *
 * @since version
 */
function get_country_name($country_id)
{
	$db = db();

	return $db->setQuery(
		'SELECT countryName ' .
		'FROM countries ' .
		'WHERE idCountry = ' . $db->quote($country_id)
	)->loadObject()->countryName;
}

/**
 *
 * @return string
 *
 * @since version
 */
function scripts(): string
{
	$str = '<script>';
	$str .= 'function copyLink() {
        /* Get the text field */
        var copyText = document.getElementById("myLink");

        /* Select the text field */
        copyText.select();

        /* Copy the text inside the text field */
        document.execCommand("copy");

        /* Alert the copied text */
        //alert("Copied the text: " + copyText.value);
    };
    
    (function ($) {
        $.fn.textWidth = function (text, font) {

            if (!$.fn.textWidth.fakeEl) $.fn.textWidth.fakeEl = $("<span>").hide().appendTo(document.body);

            $.fn.textWidth.fakeEl.text(text || this.val() || this.text() || this.attr("placeholder")).css("font", font || this.css("font"));

            return $.fn.textWidth.fakeEl.width();
        };

        var cl_width_dynamic = $(".width-dynamic");

        cl_width_dynamic.on("input", function () {
            var inputWidth = $(this).textWidth();
            $(this).css({
                width: inputWidth
            })
        }).trigger("input");


        function inputWidth(elem) {
            elem = $(this);
            console.log(elem)
        }

        //var targetElem = cl_width_dynamic;

        inputWidth(cl_width_dynamic);
    })(jQuery);';
	$str .= '</script>';

	return $str;
}