<?php

namespace BPL\Jumi\Genealogy_Matrix_Table_Executive;

require_once 'bpl/mods/genealogy_matrix_table.php';

use function BPL\Mods\Genealogy_Matrix_Table\main as genealogy;

genealogy('executive');