<?php

namespace BPL\Jumi\Reward_Redemption_Confirm;

require_once 'bpl/menu.php';
require_once 'bpl/mods/query.php';
require_once 'bpl/mods/helpers.php';

use Exception;

use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Exception\ExceptionHandler;

use function BPL\Menu\admin as menu_admin;
use function BPL\Menu\manager as menu_manager;

use function BPL\Mods\Database\Query\insert;
use function BPL\Mods\Database\Query\update;

use function BPL\Mods\Url_SEF\sef;
use function BPL\Mods\Url_SEF\qs;

use function BPL\Mods\Helpers\session_get;
use function BPL\Mods\Helpers\page_validate as page_validate_reward;
use function BPL\Mods\Helpers\input_get;
use function BPL\Mods\Helpers\db;
use function BPL\Mods\Helpers\application;
use function BPL\Mods\Helpers\time;

main();

/**
 *
 *
 * @since version
 */
function main()
{
	$usertype     = session_get('usertype');
	$admintype    = session_get('admintype');
	$account_type = session_get('account_type');
	$user_id      = session_get('user_id');
	$username     = session_get('username');

	page_validate_reward();

	$str = menu($usertype, $admintype, $account_type, $user_id, $username);

	$uid = input_get('uid');

	if ($usertype === 'Admin' || $usertype === 'manager')
	{
		if ($uid === '')
		{
			$str .= view_incentives();
		}
		else
		{
			process_confirm($user_id, $uid);
		}
	}

	echo $str;
}

/**
 * @param $usertype
 * @param $admintype
 * @param $account_type
 * @param $user_id
 * @param $username
 *
 * @return string
 *
 * @since version
 */
function menu($usertype, $admintype, $account_type, $user_id, $username): string
{
	$str = '';

	switch ($usertype)
	{
		case 'Admin':
			$str .= menu_admin($admintype, $account_type, $user_id, $username);
			break;
		case 'manager':
			$str .= menu_manager();
			break;
	}

	return $str;
}

/**
 *
 * @return array|mixed
 *
 * @since version
 */
function incentives_pending()
{
	$db = db();

	return $db->setQuery(
		'SELECT * ' .
		'FROM network_incentive ' .
		'WHERE status = ' . $db->quote('Awaiting Delivery') .
		' ORDER BY incentive_id DESC'
	)->loadObjectList();
}

/**
 * @param $item_id
 *
 * @return mixed|null
 *
 * @since version
 */
function items_incentive($item_id)
{
	$db = db();

	return $db->setQuery(
		'SELECT * ' .
		'FROM network_items_incentive ' .
		'WHERE item_id = ' . $db->quote($item_id)
	)->loadObject();
}

/**
 *
 * @return string
 *
 * @since version
 */
function view_incentives(): string
{
	$incentives = incentives_pending();

	$str = '<h1>Pending Rewards Redemption</h1>
        <p>Confirm delivery of purchases here.</p>';

	if (!empty($incentives))
	{
		$str .= '<table class="category table table-striped table-bordered table-hover">
                <thead>
                <tr>
                    <th>Date</th>
                    <th>Item</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>';

		foreach ($incentives as $incentive)
		{
			$item = items_incentive($incentive->item_id);

			$str .= '<tr>
				<td>' . date('M j, Y g:i A', $incentive->date) . '</td>
				<td><a href="' . sef(64) . qs() . 'uid=' . $item->item_id . '" target="_blank">' .
				$item->item_name . '</a></td>
				<td>' . $incentive->price . '</td>
				<td>' . $incentive->quantity . '</td>
				<td>' . $incentive->total_purchases . '</td>
				<td>' . $incentive->status . '</td>
				<td><a href="' . sef(78) . qs() . 'uid=' . $incentive->incentive_id .
				'" class="uk-button uk-button-primary">Confirm</a></td>
			</tr>';
		}

		$str .= '</tbody>
            </table>';
	}
	else
	{
		$str .= '<hr><p>No pending redemption.</p>';
	}

	return $str;
}

/**
 * @param $user_id
 * @param $uid
 *
 *
 * @since version
 */
function process_confirm($user_id, $uid)
{
	$db = db();

	try
	{
		$db->transactionStart();

		update_incentive($uid);

		logs($user_id, $uid);

		$db->transactionCommit();
	}
	catch (Exception $e)
	{
		$db->transactionRollback();
		ExceptionHandler::render($e);
	}

	application()->redirect(Uri::root(true) . '/' . sef(78),
		'Rewards redemption delivery confirmed.', 'notice');
}

/**
 * @param $uid
 *
 * @return mixed|null
 *
 * @since version
 */
function user_incentive($uid)
{
	$db = db();

	return $db->setQuery(
		'SELECT * ' .
		'FROM network_users u, network_incentive i ' .
		'WHERE u.id = i.user_id ' .
		'AND i.incentive_id = ' . $db->quote($uid)
	)->loadObject();
}

/**
 * @param $user_id
 * @param $uid
 *
 *
 * @since version
 */
function logs($user_id, $uid)
{
	$db = db();

	$incentives = user_incentive($uid);

	$activity = '<b>Rewards Redemption Delivery Confirmation: </b>' .
		items_incentive($incentives->item_id)->item_name .
		' by <a href="' . sef(44) . qs() . 'uid=' . $incentives->user_id .
		'">' . $incentives->username . '</a>.';

	insert(
		'network_activity',
		[
			'user_id',
			'sponsor_id',
			'upline_id',
			'activity',
			'activity_date'
		],
		[
			$db->quote($user_id),
			$db->quote(1),
			$db->quote(1),
			$db->quote($activity),
			$db->quote(time())
		]
	);
}

/**
 * @param $uid
 *
 *
 * @since version
 */
function update_incentive($uid)
{
	$db = db();

	update(
		'network_incentive',
		['status = ' . $db->quote('Delivered')],
		['incentive_id = ' . $db->quote($uid)]
	);
}