<?php

namespace BPL\Lib\Local\Database;

interface Db_Info
{
	public const HOST = 'localhost';
	public const USERNAME = 'u836798471_admin';
	public const PASSWORD = '4-AX262W8hSqJ@!p';
	public const DATABASE = 'u836798471_db';

    public static function connect();
}