<?php

namespace BPL\Ajax\Mods\Token\Trade\Table\Components;

use function BPL\Mods\Local\Helpers\settings;

/**
 * @param $latest
 * @param $next
 * @param $prev
 * @param $oldest
 * @param $total
 * @param $rows
 * @param $start_row
 *
 * @return string
 *
 * @since version
 */
function paginate($latest, $next, $prev, $oldest, $total, $rows, $start_row): string
{
	$limit_from = $rows * $start_row;

	$count_total = count($total);

	$latest_active   = '<input type="button" value=">|"' . $latest .
		' class="uk-panel-badge uk-badge-notification uk-badge-success">';
	$latest_disabled = '<input disabled type="button" value=">|" 
		class="uk-panel-badge uk-badge-notification uk-badge-success">';

	$next_disabled = '<input disabled type="button" value=">>" 
		class="uk-panel-badge uk-badge-notification uk-badge-warning" style="margin-right: 10%; text-align: left">';
	$next_active   = '<input type="button" value=">>"' . $next .
		' class="uk-panel-badge uk-badge-notification uk-badge-warning" style="margin-right: 10%; text-align: left">';

	$prev_disabled = '<input disabled type="button" value="<<" 
		class="uk-panel-badge uk-badge-notification uk-badge-danger" style="margin-right: 20%; text-align: left">';
	$prev_active   = '<input type="button" value="<<"' . $prev .
		' class="uk-panel-badge uk-badge-notification uk-badge-danger" style="margin-right: 20%; text-align: left">';

	$oldest_active   = '<input type="button" value="|<"' . $oldest .
		' class="uk-panel-badge uk-badge-notification uk-badge" style="margin-right: 30%; text-align: left">';
	$oldest_disabled = '<input disabled type="button" value="|<" 
		class="uk-panel-badge uk-badge-notification uk-badge" style="margin-right: 30%; text-align: left">';

	$str = $count_total > ($limit_from + $rows) ? $oldest_active : $oldest_disabled;
	$str .= $count_total > ($limit_from + $rows) ? $prev_active : $prev_disabled;
	$str .= $start_row > 0 ? $next_active : $next_disabled;
	$str .= $start_row > 0 ? $latest_active : $latest_disabled;

	return $str;
}

/**
 * @param   string  $str
 *
 * @return string
 *
 * @since version
 */
function table_head_mkt(string $str): string
{
	$str .= '<table class="category table table-striped table-bordered table-hover">';
	$str .= '<thead>';
	$str .= '<tr>';
	$str .= '<th>Price</th>';
	$str .= '<th>Qty (' . settings('trading')->token_name . ')</th>';
	$str .= '<th>Total</th>';
	$str .= '</tr>';
	$str .= '</thead>';
	$str .= '<tbody style="font-size: smaller; font-weight: bold">';

	return $str;
}

/**
 * @param           $result
 * @param   string  $color
 * @param   string  $str
 * @param   string  $button
 *
 * @return string
 *
 * @since version
 */
function table_row_mkt($result, string $color, string $str, string $button): string
{
	$total = $result->amount * $result->price;

	$str .= '<tr' . $color . '>';
	$str .= '<td>' . number_format($result->price, 8) . '</td>';
	$str .= '<td>' . number_format($result->amount, 8) . '</td>';
	$str .= '<td>' . number_format($total, 5) . $button . '</td>';
	$str .= '</tr>';

	return $str;
}